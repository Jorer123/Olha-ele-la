# bot-discord
Olha ele ae bot


Disponível em top.gg: [Olha ele ae bot](https://top.gg/bot/941468149373628468)

![Discord Bots](https://top.gg/api/widget/servers/941468149373628468.svg)
![Discord Bots](https://top.gg/api/widget/upvotes/941468149373628468.svg)
![Discord Bots](https://top.gg/api/widget/owner/941468149373628468.svg)

Se você quiser adicionar o bot no seu servidor:

https://discord.com/api/oauth2/authorize?client_id=941468149373628468&permissions=8&scope=bot%20applications.commands

Após adicionar é só entrar em um canal de voz e usar o comando: +olhaeleae
Assim que alguém entrar no mesmo canal de voz, ele já irá avisar.

Se você quiser configurar como o seu bot:

Faça o clone do repositório, e configure um arquivo .env
No arquivo .env coloque a chave Token da seguinte forma:
TOKEN=SEU_TOKEN

Salve, dê um yarn install e logo após um yarn start.
